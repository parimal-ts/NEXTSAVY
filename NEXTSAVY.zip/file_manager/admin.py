from django.contrib import admin
from .models import FileManager

# Register your models here.
admin.site.register(FileManager)